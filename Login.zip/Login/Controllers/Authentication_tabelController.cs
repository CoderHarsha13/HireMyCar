﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Login.Models;

namespace Login.Controllers
{
    public class Authentication_tabelController : Controller
    {
        private Hire_my_carEntities db = new Hire_my_carEntities();

        // GET: Authentication_tabel
        public ActionResult Index()
        {
            return View(db.Authentication_tabel.ToList());
        }

        // GET: Authentication_tabel/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Authentication_tabel authentication_tabel = db.Authentication_tabel.Find(id);
            if (authentication_tabel == null)
            {
                return HttpNotFound();
            }
            return View(authentication_tabel);
        }

        // GET: Authentication_tabel/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Authentication_tabel/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "serial_no,user_id,password,user_role")] Authentication_tabel authentication_tabel)
        {
            if (ModelState.IsValid)
            {
                db.Authentication_tabel.Add(authentication_tabel);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(authentication_tabel);
        }

        // GET: Authentication_tabel/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Authentication_tabel authentication_tabel = db.Authentication_tabel.Find(id);
            if (authentication_tabel == null)
            {
                return HttpNotFound();
            }
            return View(authentication_tabel);
        }

        // POST: Authentication_tabel/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "serial_no,user_id,password,user_role")] Authentication_tabel authentication_tabel)
        {
            if (ModelState.IsValid)
            {
                db.Entry(authentication_tabel).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(authentication_tabel);
        }

        // GET: Authentication_tabel/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Authentication_tabel authentication_tabel = db.Authentication_tabel.Find(id);
            if (authentication_tabel == null)
            {
                return HttpNotFound();
            }
            return View(authentication_tabel);
        }

        // POST: Authentication_tabel/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Authentication_tabel authentication_tabel = db.Authentication_tabel.Find(id);
            db.Authentication_tabel.Remove(authentication_tabel);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
