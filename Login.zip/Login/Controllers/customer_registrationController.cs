﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Login.Models;

namespace Login.Controllers
{
    public class customer_registrationController : Controller
    {
        private Hire_my_carEntities db = new Hire_my_carEntities();

        // GET: customer_registration
        public ActionResult Index()
        {
            return View(db.customer_registration.ToList());
        }

        // GET: customer_registration/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            customer_registration customer_registration = db.customer_registration.Find(id);
            if (customer_registration == null)
            {
                return HttpNotFound();
            }
            return View(customer_registration);
        }

        [HttpPost]
        public ActionResult Search(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }
            var results = (from move in db.customer_registration
                           where move.customer_id == id
                           select move).Take(1).ToList();


            return View("Index", results);
        }

        // GET: customer_registration/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: customer_registration/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "customer_id,first_name,last_name,age,ssn_no,address,contact_no")] customer_registration customer_registration)
        {
            if (ModelState.IsValid)
            {
                db.customer_registration.Add(customer_registration);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(customer_registration);
        }

        // GET: customer_registration/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            customer_registration customer_registration = db.customer_registration.Find(id);
            if (customer_registration == null)
            {
                return HttpNotFound();
            }
            return View(customer_registration);
        }

        // POST: customer_registration/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "customer_id,first_name,last_name,age,ssn_no,address,contact_no")] customer_registration customer_registration)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customer_registration).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(customer_registration);
        }

        // GET: customer_registration/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            customer_registration customer_registration = db.customer_registration.Find(id);
            if (customer_registration == null)
            {
                return HttpNotFound();
            }
            return View(customer_registration);
        }

        // POST: customer_registration/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            customer_registration customer_registration = db.customer_registration.Find(id);
            db.customer_registration.Remove(customer_registration);
            try
            {
                db.SaveChanges();
            }
            catch (Exception e)
            {
                TempData["Alert"] = "Customer cannot be deleted since they hired a car";
            }
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
