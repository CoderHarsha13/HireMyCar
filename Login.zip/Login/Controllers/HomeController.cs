﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Login.Models;
using System.Data.Entity;

namespace Login.Controllers
{
    public class HomeController : Controller
    {
        private Hire_my_carEntities Db = new Hire_my_carEntities();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            var list = Db.Authentication_tabel.ToList();
            foreach (var user in list)
            {
                if (user.user_id.Equals(username) && user.password.Equals(password))
                {
                    Session["Name"] = username;
                    if (user.user_role.Equals("Owner"))
                    {
                        Session["Role"] = "O";
                        return RedirectToAction("OwnerView", "Employee_info");
                    }
                    else if (user.user_role.Equals("Staff"))
                    {
                        Session["Role"] = "S";
                        return RedirectToAction("OwnerView", "Employee_info");
                    }

                }
            }
            TempData["Alert"] = "Invalid Credentails";
            return View();
        }
        public ActionResult Logout()
        {
            Session["Role"] = null;
            return View();
        }

        public ActionResult ForgotPwd()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgotPwd(string username,string email)
        {
            var list = Db.Authentication_tabel.ToList();
            foreach (var user in list)
            {
                if (user.user_id.Equals(username) && user.email.Equals(email))
                {
                    Random rnd = new Random();
                    int otp = rnd.Next(1000, 9999);
                    TempData["msgotp"] = otp;
                    TempData["userId"] = user.serial_no;
                    MailMessage message = new MailMessage();
                    SmtpClient smtp = new SmtpClient();
                    message.From = new MailAddress("HireMyCar21@gmail.com");
                    message.To.Add(new MailAddress(email));
                    message.Subject = "Your OTP for password reset HireMyCar";
                    message.IsBodyHtml = true; //to make message body as html  
                    message.Body = otp.ToString();
                    smtp.Port = 587;
                    smtp.Host = "smtp.gmail.com"; //for gmail host 
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential("HireMyCar21@gmail.com", "Blackhalk1@");
                    smtp.EnableSsl = true;
                    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtp.Send(message);
                    return RedirectToAction("ResetPwd");
                }

            }
            TempData["Alert"] = "The details entered are not valid";
            return View();
        }

        public ActionResult ResetPwd()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ResetPwd(string OTP, string Password)
        {
            if (OTP.Equals(TempData["msgotp"].ToString()))
            {
                Hire_my_carEntities db = new Hire_my_carEntities();
                var result = db.Authentication_tabel.Find(TempData["userId"]);
                result.password = Password;
                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Login");
            }
            TempData["Alert"] = "Invalid Otp";
            return View();
        }
    }

}