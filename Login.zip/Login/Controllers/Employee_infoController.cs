﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Login.Models;

namespace Login.Controllers
{
    public class Employee_infoController : Controller
    {
        private Hire_my_carEntities db = new Hire_my_carEntities();

        // GET: Employee_info
        public ActionResult Index()
        {
            return View(db.Employee_info.ToList());
        }

        // GET: Employee_info/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_info employee_info = db.Employee_info.Find(id);
            if (employee_info == null)
            {
                return HttpNotFound();
            }
            return View(employee_info);
        }

        [HttpPost]
        public ActionResult Search(int? id)
        {
            if (id == null)
            {
              return RedirectToAction("Index");
            }
            var results = (from move in db.Employee_info
                           where move.Emp_id == id
                           select move).Take(1).ToList();


            return View("Index",results);
        }

        // GET: Employee_info/Create
        public ActionResult Create()
        {
            ViewBag.GenderList = new SelectList(Enum.GetValues(typeof(Gender)));
            return View();
        }

        // POST: Employee_info/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Emp_id,First_name,Last_name,age,gender,contact_no,email")] Employee_info employee_info)
        {
            if (ModelState.IsValid)
            {
                var list = db.Employee_info.ToList().LastOrDefault();
                Authentication_tabel a = new Authentication_tabel();
                if (list != null)
                {
                    a.user_id = (list.Emp_id + 1).ToString();
                }
                else
                {
                    a.user_id = "1000";
                }
                a.password = "Test@123";
                a.user_role = "Staff";
                a.email = employee_info.email;
                db.Authentication_tabel.Add(a);
                db.Employee_info.Add(employee_info);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.GenderList = new SelectList(Enum.GetValues(typeof(Gender)));
            return View(employee_info);
        }

        // GET: Employee_info/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_info employee_info = db.Employee_info.Find(id);
            if (employee_info == null)
            {
                return HttpNotFound();
            }
            return View(employee_info);
        }

        // POST: Employee_info/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Emp_id,First_name,Last_name,age,gender,contact_no")] Employee_info employee_info)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee_info).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employee_info);
        }

        // GET: Employee_info/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_info employee_info = db.Employee_info.Find(id);
            if (employee_info == null)
            {
                return HttpNotFound();
            }
            return View(employee_info);
        }

        // POST: Employee_info/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee_info employee_info = db.Employee_info.Find(id);
            db.Employee_info.Remove(employee_info);

           
            int s = db.Authentication_tabel.First(a => a.user_id == id.ToString()).serial_no;

          
            Authentication_tabel Au = db.Authentication_tabel.Find(s);
            
           db.Authentication_tabel.Remove(Au);
            
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        public ActionResult OwnerView()
        {
            return View();
        }
        public enum Gender
        {
            Male=1, Female=2, Other=3
        }

    }
}
