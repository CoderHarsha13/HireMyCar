﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Login.Models;

namespace Login.Controllers
{
    public class RentalsController : Controller
    {
        private Hire_my_carEntities db = new Hire_my_carEntities();

        // GET: Rentals
        public ActionResult Index()
        {
            var rentals = db.Rentals.Include(r => r.car).Include(r => r.customer_registration);
            return View(rentals.ToList());
        }

        // GET: Rentals/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Rental rental = db.Rentals.Find(id);
            if (rental == null)
            {
                return HttpNotFound();
            }
            return View(rental);
        }

        [HttpPost]
        public ActionResult Search(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }
            var results = (from move in db.Rentals
                           where move.Rental_id == id
                           select move).Take(1).ToList();

            return View("Index", results);
        }

        // GET: Rentals/Create
        public ActionResult Create()
        {
            ViewBag.car_id = new SelectList(db.cars.Where(c => (bool)c.available_status), "car_id", "car_name");
            ViewBag.customer_id = new SelectList(db.customer_registration, "customer_id", "first_name");
            ViewBag.Employee_id = new SelectList(db.Employee_info, "Emp_id", "First_name");
            return View();
        }

        // POST: Rentals/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Rental_id,customer_id,car_id,Employee_id,membership_type")] Rental rental)
        {
            if (ModelState.IsValid)
            {
                db.Rentals.Add(rental);
                var result = db.cars.Find(rental.car_id);
                result.available_status = false;
                db.Entry(result).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.car_id = new SelectList(db.cars, "car_id", "car_name", rental.car_id);
            ViewBag.customer_id = new SelectList(db.customer_registration, "customer_id", "first_name", rental.customer_id);
            ViewBag.Employee_id = new SelectList(db.Employee_info, "Emp_id", "First_name", rental.Employee_id);
            return View(rental);
        }

        // GET: Rentals/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Rental rental = db.Rentals.Find(id);
            if (rental == null)
            {
                return HttpNotFound();
            }
            ViewBag.car_id = new SelectList(db.cars, "car_id", "car_name", rental.car_id);
            ViewBag.customer_id = new SelectList(db.customer_registration, "customer_id", "first_name", rental.customer_id);
            ViewBag.Employee_id = new SelectList(db.Employee_info, "Emp_id", "First_name", rental.Employee_id);
            return View(rental);
        }

        // POST: Rentals/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Rental_id,customer_id,car_id,Employee_id,membership_type")] Rental rental)
        {
            if (ModelState.IsValid)
            {
                db.Entry(rental).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.car_id = new SelectList(db.cars, "car_id", "car_name", rental.car_id);
            ViewBag.customer_id = new SelectList(db.customer_registration, "customer_id", "first_name", rental.customer_id);
            ViewBag.Employee_id = new SelectList(db.Employee_info, "Emp_id", "First_name", rental.Employee_id);
            return View(rental);
        }

        // GET: Rentals/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Rental rental = db.Rentals.Find(id);
            if (rental == null)
            {
                return HttpNotFound();
            }
            return View(rental);
        }

        // POST: Rentals/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Rental rental = db.Rentals.Find(id);
            db.Rentals.Remove(rental);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
